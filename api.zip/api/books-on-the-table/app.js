const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { v4: uuid } = require("uuid");
// const { default: nil } = require('uuid/dist/nil');

const app = express();
const port = 3000;

// Where we will keep books
let books = [];
let users = [];

app.use(cors());

// Configuring body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// -------------------------------------------------------------------
// Book
// -------------------------------------------------------------------
app.post("/book", (req, res) => {
  const book = req.body;
  book.book_id = uuid();
  books.push(book);
  res.status(201).json(book);
});

app.get("/books", (req, res) => {
  res.json({ items: books });
});

app.get("/book/:book_id", (req, res) => {
  const bookId = req.params.book_id;
  for (let book of books) {
    if (book.book_id === bookId) {
      res.json(book);
      return;
    }
  }
  res.status(404).send("Book not found");
});

app.delete("/book/:book_id", (req, res) => {
  const bookId = req.params.book_id;
  const bookIndex = books.findIndex((b) => b.book_id == bookId);

  if (bookIndex != -1) {
    books.splice(bookIndex, 1);
    res.status(200).send("Book Removed");
  } else {
    res.status(404).send("Book not found");
  }
});

app.put("/book/:book_id", (req, res) => {
  const bookId = req.params.book_id;
  const bookIndex = books.findIndex((b) => b.book_id == bookId);

  if (bookIndex != -1) {
    const book = req.body;
    book.book_id = bookId;
    books.splice(bookIndex, 1, book);
    res.json(book);
  } else {
    res.status(404).send("Book not found");
  }
});

// -------------------------------------------------------------------
// User
// -------------------------------------------------------------------

app.post("/user", (req, res) => {
  const user = req.body;
  user.user_id = uuid();
  users.push(user);
  res.status(201).json(user);
});

// -------------------------------------------------------------------
// Login
// -------------------------------------------------------------------

app.post("/security/authenticate", (req, res) => {
  const email = req.body.email;
  const passwordHash = req.body.password_hash;

  const user = users.find((u) => u.email == email);
  if (user != null) {
    res.status(200).json(user);
  } else {
    res.status(404).send("User Not Found");
  }
});

app.listen(port, () =>
  console.log(`Books On The Table listening on port ${port}!`)
);
